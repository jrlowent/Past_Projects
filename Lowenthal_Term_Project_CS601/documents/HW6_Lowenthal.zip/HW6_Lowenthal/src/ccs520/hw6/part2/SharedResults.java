package ccs520.hw6.part2;

import java.util.ArrayList;
import java.util.Iterator;

public class SharedResults {
	
	//instance variable for ArrayList with ResultsEntry parameter
	private ArrayList<ResultsEntry> results;
	
	//Default constructor that initializes ArrayList "results"
	public SharedResults() {
		results = new ArrayList<ResultsEntry>();
	}
	
	//Adds data to ArrayList results, avoids synchronization issue
	public synchronized void addToResults(ResultsEntry resultEntry, int turn) {
		results.add(resultEntry);
		notifyAll();
		try {
			int previousTurn = 0;
			if (turn == results.size()) {
				System.out.println("Calling Thread's Turn " + turn + ", " + (Thread.currentThread().getName()) + " is adding " + resultEntry + ",");
				notifyAll();
			}
			else if (turn > results.size()) {
				System.out.println("Calling Thread's turn " + turn + ", WhoseTurn " + previousTurn + " ... Wait");
				wait();
			}
			previousTurn = turn;
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		System.out.println("  Cumulative Result is " + results);
	}

	public synchronized int getResult() {
		//Returns the sum of the count entry values
		Iterator<ResultsEntry> resultsItr = results.iterator(); //Creates iterator object on ArrayList
		int sum = 0; //Initializes sum
		//iterate through the count variable in the array, add to sum
		while (resultsItr.hasNext()) {
			int currentCharCount = resultsItr.next().getCount();
			sum += currentCharCount;
		}
		return sum;
	}	
}
package cs520.hw6.part1;

import java.util.ArrayList;
import java.util.Iterator;

public class SharedResults {
	
	//instance variable for ArrayList with ResultsEntry parameter
	private ArrayList<ResultsEntry> results;
	
	//Default constructor that initializes ArrayList "results"
	public SharedResults() {
		results = new ArrayList<ResultsEntry>();
	}
	
	//Adds data to ArrayList results, avoids synchronization issue
	public synchronized void addToResults(ResultsEntry resultEntry) {
		results.add(resultEntry);
		System.out.println(Thread.currentThread().getName() + " is adding " + resultEntry.toString());
		System.out.println("  Cumulative Results are " + results);
	}

	public synchronized int getResult() {
		//Returns the sum of the count entry values
		Iterator<ResultsEntry> resultsItr = results.iterator(); //Creates iterator object on ArrayList
		int sum = 0; //Initializes sum
		//iterate through the count variable in the array, add to sum
		while (resultsItr.hasNext()) {
			int currentCharCount = resultsItr.next().getCount();
			sum += currentCharCount;
		}
		return sum;
	}	
}
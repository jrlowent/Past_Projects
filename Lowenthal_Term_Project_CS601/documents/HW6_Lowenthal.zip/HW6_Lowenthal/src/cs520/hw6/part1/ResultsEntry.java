package cs520.hw6.part1;

public class ResultsEntry {
	 
	//Instance variables
	private int count;
	private char target;
	
	//Constructor that initializes instance variables
	ResultsEntry(char target, int count) {
		this.target = target;
		this.count = count;
	}

	//getter methods
	public int getCount() {
		return count;
	}
	public char getTarget() {
		return target;
	}
	
	//Override toString method to return target and count
	public String toString() {
		return ("<" + target + "," + count + ">");
	}
}
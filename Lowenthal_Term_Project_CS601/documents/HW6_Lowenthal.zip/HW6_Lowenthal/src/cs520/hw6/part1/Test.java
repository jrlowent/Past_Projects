package cs520.hw6.part1;

import java.io.*;
import java.net.*;

public class Test {
	
	public static void main(String[] args) {
		
		//store url in a String object
		String webPage = "http://norvig.com/big.txt";
		//create a URL object
		URL urlObject = null;
		//create a stringbuffer object to add data to
		StringBuffer strBuffer = new StringBuffer();
		//create a variable to store each line
		String inputLineRead;
		//create SharedResults object
		SharedResults sharedData;
		//create LongTask object
		LongTask longTaskObject;
		//create variable to store the char
		char localTarget;
		//create bufferedReader object
		BufferedReader bReader = null;
		
		try { //Anticipates any issues
			urlObject = new URL(webPage);
			//generate the inputstream object as a conduit for the data
			InputStreamReader inputStreamObject = new InputStreamReader(urlObject.openStream());
			//generates wrapper object for input stream
			bReader = new BufferedReader(inputStreamObject);
			
			//loop through bReader line by line
			while ((inputLineRead = bReader.readLine()) != null) {
				//convert input to lowercase
				String inputLineLowercase = inputLineRead.toLowerCase();
				//add to stringbuffer object
				strBuffer.append(inputLineLowercase + "\n");
			}
			
			System.out.println("Input Data length: " + strBuffer.length());
			//Instantiate SharedResults object
			sharedData = new SharedResults();
			
			LongTask[] longTaskArray = new LongTask[26];
			//loops through alphabet, places into LongTaskObject, starts thread for each, 
			for (int i = 0; i < 26; i++) {
				localTarget = (char)(i + 97);
				longTaskObject = new LongTask(sharedData, strBuffer, localTarget);
				longTaskArray[i] = (longTaskObject);
				longTaskObject.start();
				System.out.println("Thread " + longTaskObject.getName() + " running");
			}
			for (LongTask longTaskObject2 : longTaskArray) {
				longTaskObject2.join();//causes each thread to finish before executing remaining code
			}
			
			System.out.println("Alphabet Count  = " + sharedData.getResult());//gets cumulative char count
			
		} catch (MalformedURLException e) { //if page cannot be stored in URL Object
			e.printStackTrace();
		} catch (IOException e) { //issue with processing data for file
			e.printStackTrace();
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		finally {
        	try {
        		//tries to close the file
    			bReader.close();
        	}
        	catch (IOException e) {//Anticipates attempt to close file never found
        		System.out.println("There is no bufferedReader to be closed");
        		e.printStackTrace();
        	}
	    }
	}
}

package cs520.hw6.part1;

public class LongTask extends Thread {
	
	//instance variables, limit access to Longtask
	private SharedResults sharedData;
	private StringBuffer inputData;
	private char target;
	
	/*constructor that takes sharedData, inputData, target as arguments, 
	stores in like-named instance variables; names thread*/
	public LongTask(SharedResults sharedData, StringBuffer inputData, char target) {
		this.sharedData = sharedData;
		this.inputData = inputData;
		this.target = target;
		String name = "Thread_" + target; //formats the name of the thread using target
		this.setName(name); //names the thread in the superclass Thread
	}
	
	public void run() {
		//loop through inputData, counts each occurrence of each letter in alphabet
		char character = 'a';
		int count = 0;
		for (int i = 0; i < inputData.length(); i++) {
			character = inputData.charAt(i);
			if (target == character) {
				count += 1;
			}
		}
		ResultsEntry resultEntry = new ResultsEntry(target, count);//Instantiates ResultsEntry and adds target, count
		sharedData.addToResults(resultEntry);//adds entry to Shared Results array
	}
	
}